package t3a5;

import java.util.Scanner;

/**
 *
 * @author esmer
 */
public class Menu {

    public void menu() {
        Cuenta cuenta = new Cuenta();
        Scanner obj = new Scanner(System.in);
        System.out.println("BIENVENIDO AL BANCO...\n"
                + "1.-Consultar saldo\n"
                + "2.-Consultar saldo de cuenta\n"
                + "3.-Retirar efectivo\n"
                + "4.-Otras opciones\n"
                + "5.-Salir\n"
                + "\n\nElije una operxion");
        int operacion = obj.nextInt();
        switch (operacion) {
            case 1:
                cuenta.consultarSaldo();
                break;
            case 2:
                cuenta.estadoDeCuenta();
                break;
            case 3:
                cuenta.retirarEfectivo();
                break;
            case 4:
                System.out.println("1)Seguros"
                        + "\n2)Creditos \nElija uno");
                int opcion = obj.nextInt();
                switch (opcion) {
                    case 1:
                        cuenta.seguros();
                        break;
                    case 2:
                        cuenta.creditos();
                        break;
                    default:
                        System.out.println("Elija una opcion v�lida");
                }
                break;
            case 5:
                cuenta.salir();
                break;
            default:
                System.out.println("Elije un operacion valida");
        }

    }
}
