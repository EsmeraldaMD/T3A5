package t3a5;

public class T3A5 {


    
    public static void main(String[] args) {
        operacion();
    }
    
    public static void operacion() {
                Menu menu = new Menu();
        menu.menu();
    }
}
    

